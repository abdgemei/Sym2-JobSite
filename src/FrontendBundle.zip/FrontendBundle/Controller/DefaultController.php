<?php

namespace Kareerak\FrontendBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class DefaultController extends Controller
{
    /**
     * @Route("/hello/{name}")
     * @Template()
     */
    public function indexAction($name)
    {
        return array('name' => $name);
    }

    public function addAction()
    {
        //echo "<pre>"; print_r($this->getRequest()->getMethod()); die;
        $request = $this->getRequest();
        $job = new Job();
        $form = $this->createFormBuilder($job)
                ->add('title', 'text')
                ->add('description', 'textarea')
                ->getForm();

        if($request->getMethod() == 'POST') {
            $form->bindRequest($request);
            if($form->isValid()) {
                // pass values to database
            } else {
                // return back to page
            }
        } else {
            return $this->render('KareerakFrontendBundle:Default:add.html.twig', array('form' => $form->createView()));
        }
    }
}