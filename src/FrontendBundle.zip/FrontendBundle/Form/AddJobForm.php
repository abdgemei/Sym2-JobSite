<?php

namespace Kareerak\JobsBundle\Form;

use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\FormBuilder;


class AddJobForm extends FormFactory
{
}