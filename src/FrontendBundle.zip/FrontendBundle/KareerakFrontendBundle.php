<?php

namespace Kareerak\FrontendBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KareerakFrontendBundle extends Bundle
{
}
